/****************************************************************************
** $Id: qmetaobj.h,v 1.4 1996/01/03 10:41:53 hanord Exp $
**
** Definition of QMetaObject class
**
** Author  : Haavard Nord
** Created : 930419
**
** Copyright (C) 1993-1996 by Troll Tech AS.  All rights reserved.
**
*****************************************************************************/

#ifndef QMETAOBJ_H
#define QMETAOBJ_H

#include "qconnect.h"

enum QAccess { QPRIVATE, QPROTECTED, QPUBLIC, QUNKNOWN };


struct QMetaData				// member function meta data
{						//   for signals and slots
    QMetaData(){ access = QUNKNOWN; }
    char   *name;				// - member name
    QMember ptr;				// - member pointer
    QAccess access;				// - member access
};


class QMetaObject				// meta object class
{
public:
    QMetaObject( const char *class_name, const char *superclass_name,
		 QMetaData *slot_data,	int n_slots,
		 QMetaData *signal_data, int n_signals );
   ~QMetaObject();

    const char	*className()		const { return classname; }
    const char	*superClassName()	const { return superclassname; }

    QMetaObject *superClass()		const { return superclass; }

    int		 nSlots( bool=FALSE )	const;
    int		 nSignals( bool=FALSE ) const;

    QMetaData	*slot( const char *, bool=FALSE )   const;
    QMetaData	*signal( const char *, bool=FALSE ) const;
    QMetaData	*slot( const char *, QMetaObject** )   const;
    QMetaData	*signal( const char *, QMetaObject** ) const;

    QMetaData	*slot( int index, bool=FALSE )	    const;
    QMetaData	*signal( int index, bool=FALSE )    const;

private:
    QMemberDict *init( QMetaData *, int );
    QMetaData	*mdata( int code, const char *, bool, QMetaObject** =0 ) const;
    QMetaData	*mdata( int code, int, bool ) const;

    char	*classname;			// class name
    char	*superclassname;		// super class name
    QMetaObject *superclass;			// super class meta object
    QMetaData	*slotData;			// slot meta data
    QMemberDict *slotDict;			// slot dictionary
    QMetaData	*signalData;			// signal meta data
    QMemberDict *signalDict;			// signal dictionary
};


#endif // QMETAOBJ_H
